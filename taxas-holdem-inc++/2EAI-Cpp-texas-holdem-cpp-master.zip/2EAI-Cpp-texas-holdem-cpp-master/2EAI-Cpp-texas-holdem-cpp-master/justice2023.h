#ifndef JUSTICE2023_H
#define JUSTICE2023_H
#include "player.h"

namespace PXL2023
{
class JUSTICE2023:public Player
{
public:
    JUSTICE2023(   unsigned char instance=0): Player(instance){}
    const char* getName() const;
    int willYouRaise(unsigned int totalBet);


private:
    void talkSmack();

};

}
#endif // JUSTICE2023_H
