#include "justice2023.h"
#include "game.h"


    namespace PXL2023
    {



    const char * JUSTICE2023::getName() const
    {
        return "justice";
    }

    int JUSTICE2023::willYouRaise( unsigned int totalBet )
    {
        PokerRank mijnHandRank = getRank();
        if( getTable()->isPreFlop() ) //Pre flop
        {
            if( getHand().getFirstCard()->getSuit() == getHand().getSecondCard()->getSuit() )
            { //suited hands
                int diffBetweenOrderedCards = mijnHandRank.getHand().at(0) - mijnHandRank.getHand().at(1);
                if( diffBetweenOrderedCards == 1 || diffBetweenOrderedCards == 13 )
                { //suited connected
                    return ( getGame()->getBlind() * 4 ) - totalBet; //max 7x blind and fold otherwise
                }
                return ( getGame()->getBlind() * 2 ) - totalBet; //max 3x blind and fold otherwise
            }


            if( getHand().getFirstCard()->getRank() == getHand().getSecondCard()->getRank() )
            { //1 pair to start
                return ( getGame()->getBlind() * 10 ) - totalBet; //max 5x blind and fold otherwise
            }

            if( totalBet > getGame()->getBlind() * 2 )
            {
                return -100;
            }
            return 0;
        }



        else if( getTable()->isFlop() )
        { //on flop
            if(getHand().getMyRank().handValue() >= ONE_PAIR)
            {
                if(getHand().getFirstCard()->getRank() >10|| getHand().getSecondCard()->getRank()>10)
                {
                     return(8-getGame()->getHighestBet());
                }
                else
                     {
                         return(4-getGame()->getHighestBet());
                     }

            }
            if(getHand().getMyRank().handValue() >= TWO_PAIR)
            {
                return(8-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= THREE_OF_A_KIND)
            {
                return(10-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= STRAIGHT)
            {
                return(12-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= FLUSH)
            {
                return(14-getGame()->getHighestBet());
            }

            if(getHand().getMyRank().handValue() >= FULL_HOUSE)
            {
                return(20-getGame()->getHighestBet());
            }
            else{
                return(-100);
                talkSmack();
            }

        }
        else if( getTable()->isTurn() )
        { //on turn
            if(getHand().getMyRank().handValue() >= ONE_PAIR)
            {
                if(getHand().getFirstCard()->getRank() >10|| getHand().getSecondCard()->getRank()>10)
                {
                         return(8-getGame()->getHighestBet());
                }
                else
                {
                         return(4-getGame()->getHighestBet());
                }

            }
            if(getHand().getMyRank().handValue() >= TWO_PAIR)
            {
                return(8-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= THREE_OF_A_KIND)
            {
                return(15-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= STRAIGHT)
            {
                return(17-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= FLUSH)
            {
                return(20-getGame()->getHighestBet());
            }

            if(getHand().getMyRank().handValue() >= FULL_HOUSE)
            {
                return(25-getGame()->getHighestBet());
            }
            else{return(-100);}
        }
        else
        { //on river
            if(getHand().getMyRank().handValue() >= ONE_PAIR)
            {
                if(getHand().getFirstCard()->getRank() >10|| getHand().getSecondCard()->getRank()>10)
                {
                         return(8-getGame()->getHighestBet());
                }
                else
                {
                         return(4-getGame()->getHighestBet());
                }

            }
            if(getHand().getMyRank().handValue() >= TWO_PAIR)
            {
                return(8-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= THREE_OF_A_KIND)
            {
                return(15-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= STRAIGHT)
            {
                return(17-getGame()->getHighestBet());
            }
            if(getHand().getMyRank().handValue() >= FLUSH)
            {
                return(20-getGame()->getHighestBet());
            }

            if(getHand().getMyRank().handValue() >= FULL_HOUSE)
            {
                return(25-getGame()->getHighestBet());
            }
            else{return(-100);}
        }
    }
    void JUSTICE2023::talkSmack()
    {
        std::cout << "woepsie " << 42 << std::endl;
    }
    }



